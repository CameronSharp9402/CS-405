// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <string>
#include <limits>

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // The account_number variable was not changed or moved.
    // The assignment requires this variable to remain directly before the user input variable.
    const std::string account_number = "CharlieBrown42";

    // The input buffer size remains 20 characters.
    // Using a fixed-size character array requires validating input length
    // to prevent users from overwriting memory beyond the array.
    char user_input[20];

    std::cout << "Enter a value: ";

    // getline() limits the number of characters stored in user_input.
    // The second parameter tells getline the maximum number of characters
    // that can safely be placed into the array, preventing buffer overflow.
    std::cin.getline(user_input, sizeof(user_input));

    // If the input stream failed because the user entered more characters
    // than the buffer can hold, this condition will be triggered.
    if (std::cin.fail())
    {
        // Clear the error state so the program can continue running.
        std::cin.clear();

        // Remove the remaining characters from the input stream.
        // This prevents extra user input from affecting later operations.
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        // Notify the user that their input exceeded the allowed size.
        std::cout << "Error: Input exceeded the maximum allowed length of "
            << sizeof(user_input) - 1 << " characters." << std::endl;
    }

    std::cout << "You entered: " << user_input << std::endl;

    // The account number remains unchanged because user input is restricted
    // to the allocated memory size of user_input.
    std::cout << "Account Number = " << account_number << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
