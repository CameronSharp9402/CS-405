// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits
#include <type_traits>  // std::is_integral

/// <summary>
/// Modified to detect numeric overflow before performing addition.
/// The function now returns true when the calculation succeeds and
/// false if an overflow would occur. The calculated value is returned
/// through the result reference parameter.
/// </summary>
template <typename T>
bool add_numbers(T const& start, T const& increment,
    unsigned long int const& steps, T& result)
{
    result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Only integer types can overflow in the traditional sense
        if (std::is_integral<T>::value)
        {
            // For integral data types, check whether adding the next increment
            // would exceed the maximum value allowed for the current type.
            if (increment > 0 &&
                result > std::numeric_limits<T>::max() - increment)
            {
                return false;
            }

            // Also check whether adding a negative value would exceed the
            // minimum value allowed for the current type.
            if (increment < 0 &&
                result < std::numeric_limits<T>::lowest() - increment)
            {
                return false;
            }
        }

        // Safe to perform the addition because no overflow was detected.
        result += increment;
    }

    return true;
}

/// <summary>
/// Modified to detect numeric underflow before performing subtraction.
/// The function returns false if the subtraction would exceed the valid
/// numeric range for the data type.
/// </summary>
template <typename T>
bool subtract_numbers(T const& start, T const& decrement,
    unsigned long int const& steps, T& result)
{
    result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        if (std::is_integral<T>::value)
        {
            // Check whether subtracting the decrement would move the value below
            // the minimum value supported by this data type.
            if (decrement > 0 &&
                result < std::numeric_limits<T>::lowest() + decrement)
            {
                return false;
            }

            // If the decrement is negative, subtraction becomes addition, so check
            // that the result will not exceed the maximum value.
            if (decrement < 0 &&
                result > std::numeric_limits<T>::max() + decrement)
            {
                return false;
            }
        }

        // Safe to subtract because the operation will remain within the
        // allowable numeric range.
        result -= decrement;
    }

    return true;
}

//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character. 

template <typename T>
void test_overflow()
{
    // TODO: The add_numbers template function will overflow in the second method call
    //        You need to change the add_numbers method to:
    //        1. Detect when an overflow will happen
    //        2. Prevent it from happening
    //        3. Return the correct value when no overflow happened or
    //        4. Return something to tell test_overflow the addition failed
    //        NOTE: The add_numbers method must remain a template in the NumericFunctions header.
    //
    //        You need to change the test_overflow method to:
    //        1. Detect when an add_numbers failed
    //        2. Inform the user the overflow happened
    //        3. A successful result displays the same result as before you changed the method
    //        NOTE: You cannot change anything between START / END DO NOT CHANGE
    //              The test_overflow method must remain a template in the NumericOverflows source file
    //
    //  There are more than one possible solution to this problem. 
    //  The solution must work for all of the data types used to call test_overflow() in main().

    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we add each step (result should be: start + (increment * steps))
    const T increment = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    T result;

    std::cout << "\tAdding Numbers Without Overflow (" << +start
        << ", " << +increment << ", " << steps << ") = ";

    // The function now returns a Boolean indicating whether the
    // addition completed successfully. If false is returned,
    // an overflow was prevented.
    bool overflow = !add_numbers(start, increment, steps, result);

    std::cout << "Overflow: " << std::boolalpha << overflow
        << " Result: " << +result << std::endl;

    std::cout << "\tAdding Numbers With Overflow (" << +start
        << ", " << +increment << ", " << (steps + 1) << ") = ";

    // The function now returns a Boolean indicating whether the
    // subtraction completed successfully. If false is returned,
    // an underflow was prevented.
    overflow = !add_numbers(start, increment, steps + 1, result);

    std::cout << "Overflow: " << std::boolalpha << overflow;

    if (!overflow)
        std::cout << " Result: " << +result;

    std::cout << std::endl;
}

template <typename T>
void test_underflow()
{
    // TODO: The subtract_numbers template function will underflow in the second method call
    //        You need to change the subtract_numbers method to:
    //        1. Detect when an underflow will happen
    //        2. Prevent it from happening
    //        3. Return the correct value when no underflow happened or
    //        4. Return something to tell test_underflow the subtraction failed
    //        NOTE: The subtract_numbers method must remain a template in the NumericFunctions header.
    //
    //        You need to change the test_underflow method to:
    //        1. Detect when an subtract_numbers failed
    //        2. Inform the user the underflow happened
    //        3. A successful result displays the same result as before you changed the method
    //        NOTE: You cannot change anything between START / END DO NOT CHANGE
    //              The test_underflow method must remain a template in the NumericOverflows source file
    //
    //  There are more than one possible solution to this problem. 
    //  The solution must work for all of the data types used to call test_overflow() in main().

    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we subtract each step (result should be: start - (increment * steps))
    const T decrement = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    T result;

    std::cout << "\tSubtracting Numbers Without Overflow (" << +start
        << ", " << +decrement << ", " << steps << ") = ";

    bool underflow = !subtract_numbers(start, decrement, steps, result);

    std::cout << "Underflow: " << std::boolalpha << underflow
        << " Result: " << +result << std::endl;

    std::cout << "\tSubtracting Numbers With Overflow (" << +start
        << ", " << +decrement << ", " << (steps + 1) << ") = ";

    underflow = !subtract_numbers(start, decrement, steps + 1, result);

    std::cout << "Underflow: " << std::boolalpha << underflow;

    if (!underflow)
        std::cout << " Result: " << +result;

    std::cout << std::endl;
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Undeflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    //  create a string of "*" to use in the console
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    // run the overflow tests
    do_overflow_tests(star_line);

    // run the underflow tests
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu